// Shared types and schemas between client and server
// Add your data models here when needed

export type ExampleType = {
  id: string;
  name: string;
};
